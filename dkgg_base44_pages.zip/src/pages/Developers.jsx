import { Link } from 'react-router-dom';

const S = {
  eyebrow: {
    fontFamily: 'DM Sans, sans-serif',
    fontSize: '13px',
    fontWeight: 600,
    letterSpacing: '0.14em',
    textTransform: 'uppercase',
    color: '#F06A2A',
    marginBottom: '20px',
    display: 'block',
  },
  sectionLabel: {
    fontFamily: 'DM Sans, sans-serif',
    fontSize: '11px',
    fontWeight: 600,
    letterSpacing: '0.14em',
    textTransform: 'uppercase',
    color: '#97A2AF',
    marginBottom: '16px',
    display: 'block',
  },
};

const PILLARS = [
  {
    number: '01',
    label: 'Speed',
    title: 'Two-week closes when it matters.',
    img: 'https://media.base44.com/images/public/6a2feb671c52d1dd97abea29/34aabd056_developers1.png',
    body: [
      'We understand that timing is everything in real estate. We can fund in as little as two weeks — if needed, even less. No unnecessary delays, no moving goalposts. When we say we fund, we fund.',
      'We do ask one thing in return: keep your end of the process moving and have your documentation ready. A fast close is a two-way street.',
    ],
  },
  {
    number: '02',
    label: 'Expertise',
    title: 'Fluent in your deal from day one.',
    img: 'https://media.base44.com/images/public/6a2feb671c52d1dd97abea29/cdc7eac7a_developers2.png',
    body: [
      "We don't wander off into areas we are not familiar with. Our background in real estate investment, and mastery of fix-and-flip and new construction is where we are at home.",
      "That focused expertise means we understand your deal from day one — the risks, the timeline, and what it takes to make it succeed. You're not explaining your business to someone who doesn't speak the language. We're developers just like you.",
    ],
  },
  {
    number: '03',
    label: 'Partnership',
    title: 'Genuinely in it with you.',
    img: 'https://media.base44.com/images/public/6a2feb671c52d1dd97abea29/d34cd3c6a_developers3.png',
    body: [
      "We're not a set-it-and-forget-it lender. Once we're in your deal, we're genuinely invested in its success. We stay engaged, we want to know how things are progressing, and if something comes up — we want to help solve it.",
      "That's not typical for a private lender, but it is what sets us apart.",
    ],
  },
];

export default function Developers() {
  return (
    <div>
      {/* HERO — text left, wide image banner below */}
      <section style={{ background: '#0A1A33', paddingTop: '160px', paddingBottom: '0' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '0 32px' }}>
          <div style={{ maxWidth: '560px', paddingBottom: '56px' }}>
            <span style={S.eyebrow}>For developers</span>
            <h1 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: 'clamp(36px, 5vw, 60px)', lineHeight: 1.1, color: '#FFFFFF', marginBottom: '20px' }}>
              Funding for real estate developers.
            </h1>
            <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '18px', lineHeight: 1.6, color: 'rgba(255,255,255,0.65)', marginBottom: '36px' }}>
              Bridge the gap. Close faster. Work with a lender who's genuinely on your side.
            </p>
            <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
              <Link to="/deal-machine" style={{ background: '#7FCFE3', color: '#0A1A33', fontFamily: 'DM Sans, sans-serif', fontSize: '15px', fontWeight: 700, textDecoration: 'none', padding: '13px 28px', borderRadius: '4px', display: 'inline-block' }}>
                Run your deal →
              </Link>
              <a href="mailto:dellyinvests@dkgoldengate.com" style={{ background: 'transparent', color: '#FFFFFF', fontFamily: 'DM Sans, sans-serif', fontSize: '15px', fontWeight: 500, textDecoration: 'none', padding: '13px 28px', borderRadius: '4px', border: '1.5px solid rgba(255,255,255,0.3)', display: 'inline-block' }}>
                Talk to Delly
              </a>
            </div>
          </div>
        </div>
        {/* Wide image banner — bleeds to edges within max container */}
        <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '0 32px' }}>
          <div style={{ borderRadius: '8px 8px 0 0', overflow: 'hidden' }}>
            <img
              src="https://base44.app/api/apps/69b82174571b99319d3f3dbc/files/mp/public/69b82174571b99319d3f3dbc/de27897f3_developer.png"
              alt="Real estate construction site"
              style={{ width: '100%', height: '420px', objectFit: 'cover', display: 'block' }}
            />
          </div>
        </div>
      </section>

      {/* WHAT WE FUND */}
      <section style={{ background: '#FFFFFF', padding: '100px 0' }}>
        <div style={{ maxWidth: '740px', margin: '0 auto', padding: '0 32px' }}>
          <span style={S.sectionLabel}>What we fund</span>
          <h2 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: 'clamp(28px, 3.5vw, 48px)', color: '#0A1A33', lineHeight: 1.15, marginBottom: '20px' }}>
            Narrow by design.<br />Deep by experience.
          </h2>
          <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '17px', lineHeight: 1.7, color: '#4B5563', marginBottom: '36px' }}>
            We specialize in short-term residential investment properties. Our focus is narrow by design — fix & flip and new construction is our niche and we know it well.
          </p>

          <ul style={{ listStyle: 'none', padding: 0, margin: '0 0 32px' }}>
            {[
              'Fix & flip and new construction — residential investment properties only',
              'Single family through multifamily',
              'Second-position bridge & gap funding — and first-position whole-deal funding',
              'Nationwide across most U.S. states',
              'Gap funding $30K–$500K · whole-deal $100K to several million',
            ].map((item) => (
              <li key={item} style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '16px', color: '#0A1A33', padding: '12px 0', borderBottom: '1px solid #ECEFF3', display: 'flex', alignItems: 'flex-start', gap: '12px' }}>
                <span style={{ width: '20px', height: '20px', borderRadius: '50%', background: '#7FCFE3', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', marginTop: '1px' }}>
                  <svg width="10" height="8" viewBox="0 0 10 8" fill="none"><path d="M1 4l2.5 2.5L9 1" stroke="#0A1A33" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
                </span>
                {item}
              </li>
            ))}
          </ul>

          <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '14px', color: '#97A2AF', lineHeight: 1.6 }}>
            <strong style={{ color: '#4B5563' }}>Not our wheelhouse:</strong> commercial, c-space, primary residences, long-term conventional mortgages
          </p>

          {/* Dark quote block */}
          <div style={{ background: '#0F2545', borderRadius: '8px', padding: '36px 40px', marginTop: '48px' }}>
            <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '17px', lineHeight: 1.7, color: 'rgba(255,255,255,0.85)', margin: 0 }}>
              Our approach is boutique by design. We take on fewer deals so we can give each one the attention it deserves — that selectivity isn't a limitation, it's how we deliver.
            </p>
          </div>
        </div>
      </section>

      {/* THREE PILLARS — white bg, images above cards */}
      <section style={{ background: '#FFFFFF', padding: '80px 0 60px', borderTop: '1px solid #ECEFF3' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '0 32px' }}>
          <div style={{ marginBottom: '56px' }}>
            <span style={S.sectionLabel}>Three pillars</span>
            <h2 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: 'clamp(28px, 3.5vw, 48px)', color: '#0A1A33', lineHeight: 1.15 }}>
              Why partner with<br />DK Goldengate?
            </h2>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '28px' }} className="grid-cols-3-1">
            {PILLARS.map((p) => (
              <div key={p.number}>
                <div style={{ borderRadius: '6px', overflow: 'hidden', marginBottom: '24px' }}>
                  <img src={p.img} alt={p.title} style={{ width: '100%', height: '240px', objectFit: 'cover', display: 'block' }} />
                </div>
                <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '10px', fontWeight: 700, letterSpacing: '0.14em', textTransform: 'uppercase', color: '#97A2AF', marginBottom: '10px' }}>
                  {p.number} · {p.label}
                </div>
                <h3 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: '22px', color: '#0A1A33', lineHeight: 1.2, marginBottom: '16px' }}>{p.title}</h3>
                {p.body.map((para, i) => (
                  <p key={i} style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '14px', lineHeight: 1.7, color: '#4B5563', marginBottom: '12px' }}>{para}</p>
                ))}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA — dark card, quote left + buttons right */}
      <section style={{ background: '#F6F8FA', padding: '48px 0', borderTop: '1px solid #DCE2EA' }}>
        <div style={{ maxWidth: '900px', margin: '0 auto', padding: '0 32px' }}>
          <div style={{ background: '#0F2545', borderRadius: '8px', padding: '48px 52px' }}>
            <div style={{ borderLeft: '3px solid #F06A2A', paddingLeft: '24px', marginBottom: '48px' }}>
              <p style={{ fontFamily: 'PT Serif, Georgia, serif', fontSize: 'clamp(16px, 2vw, 21px)', lineHeight: 1.65, color: 'rgba(255,255,255,0.9)', fontStyle: 'italic', margin: 0 }}>
                Our ultimate goal isn't a long list of one-time transactions. We want to grow with you — and if we're successful together, we want to be the ones funding your next deal too.
              </p>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '40px', alignItems: 'start' }} className="grid-cols-hero">
              <div>
                <h3 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: 'clamp(20px, 2.5vw, 28px)', color: '#FFFFFF', lineHeight: 1.2, marginBottom: '12px' }}>
                  Ready to discuss your project?
                </h3>
                <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '14px', lineHeight: 1.65, color: 'rgba(255,255,255,0.5)', margin: 0 }}>
                  Reach out and let's see if your deal is a fit. Initial conversations are always no-obligation, free of charge, and confidential.
                </p>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                <Link to="/deal-machine" style={{ background: '#7FCFE3', color: '#0A1A33', fontFamily: 'DM Sans, sans-serif', fontSize: '14px', fontWeight: 700, textDecoration: 'none', padding: '13px 20px', borderRadius: '4px', textAlign: 'center' }}>
                  Run your deal →
                </Link>
                <a href="mailto:dellyinvests@dkgoldengate.com" style={{ background: 'transparent', color: '#7FCFE3', fontFamily: 'DM Sans, sans-serif', fontSize: '14px', fontWeight: 500, textDecoration: 'none', padding: '13px 20px', borderRadius: '4px', border: '1px solid rgba(127,207,227,0.3)', textAlign: 'center' }}>
                  dellyinvests@dkgoldengate.com
                </a>
                <a href="https://calendar.google.com/calendar/appointments/schedules/AcZssZ2RR4bbnI4HKaSNmo-S8k16p1x_X5V0IQizHfQ9x1QM_gilna503I8efwnHPgTy2_8CwCjd9290?gv=true" target="_blank" rel="noopener noreferrer" style={{ background: 'transparent', color: 'rgba(255,255,255,0.55)', fontFamily: 'DM Sans, sans-serif', fontSize: '14px', fontWeight: 500, textDecoration: 'none', padding: '13px 20px', borderRadius: '4px', border: '1px solid rgba(255,255,255,0.15)', textAlign: 'center' }}>
                  Book an appointment
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}