import { useState } from 'react';
import { base44 } from '@/api/base44Client';

const PROJECTS = [
  { name: 'The Mansion - Timeless Charme 2.0', region: 'South', property_type: 'Single-family', strategy: 'Fix & Flip', status: 'Completed', featured: true, sort_order: 1 },
  { name: 'The Canyon - A Remodel Masterpiece', region: 'West Coast', property_type: 'Single-family', strategy: 'Fix & Flip', status: 'Completed', featured: true, sort_order: 2 },
  { name: 'The Townhouse - From Beast to Beauty', region: 'East Coast', property_type: 'Single-family', strategy: 'Fix & Flip', status: 'Completed', featured: true, sort_order: 3 },
  { name: 'The Getaway - Tranquil Living on over 1 Acre', region: 'Northwest', property_type: 'Single-family', strategy: 'Fix & Flip', status: 'Completed', featured: false, sort_order: 4 },
  { name: 'The New Kid on the Block', region: 'South', property_type: 'Single-family', strategy: 'New Construction', status: 'Completed', featured: false, sort_order: 5 },
  { name: 'The Space Wonder - Garage Conversion DeLuxe', region: 'West Coast', property_type: 'Single-family', strategy: 'Fix & Flip', status: 'Completed', featured: false, sort_order: 6 },
  { name: 'The Classic - Gingerbread house with a Modern Twist', region: 'Midwest', property_type: 'Single-family', strategy: 'Fix & Flip', status: 'Completed', featured: false, sort_order: 7 },
  { name: 'The Craftsman - History meets Modern Living', region: 'Midwest', property_type: 'Single-family', strategy: 'Fix & Flip', status: 'Completed', featured: false, sort_order: 8 },
  { name: 'The Ranch - One of its Kind-Edition', region: 'South', property_type: 'Single-family', strategy: 'Fix & Flip', status: 'Completed', featured: false, sort_order: 9 },
  { name: 'The Plus Size - Every Inch, Custom Made', region: 'South', property_type: 'Single-family', strategy: 'Fix & Flip', status: 'Completed', featured: false, sort_order: 10 },
  { name: 'The Sunset - Small But Mighty', region: 'South', property_type: 'Single-family', strategy: 'Fix & Flip', status: 'Completed', featured: false, sort_order: 11 },
  { name: 'The Longfellow - From Tattered to Timeless', region: 'East Coast', property_type: 'Single-family', strategy: 'Fix & Flip', status: 'Completed', featured: false, sort_order: 12 },
];

export default function SeedProjects() {
  const [log, setLog] = useState([]);
  const [running, setRunning] = useState(false);
  const [done, setDone] = useState(false);

  async function seed() {
    setRunning(true);
    setLog([]);
    for (const p of PROJECTS) {
      try {
        await base44.entities.Project.create(p);
        setLog(l => [...l, `✓ ${p.name}`]);
      } catch (e) {
        setLog(l => [...l, `✗ ${p.name} — ${e.message}`]);
      }
    }
    setRunning(false);
    setDone(true);
  }

  return (
    <div style={{ maxWidth: '640px', margin: '120px auto', padding: '0 32px', fontFamily: 'DM Sans, sans-serif' }}>
      <h1 style={{ fontFamily: 'PT Serif, Georgia, serif', fontSize: '32px', color: '#0A1A33', marginBottom: '8px' }}>Seed Projects</h1>
      <p style={{ color: '#97A2AF', fontSize: '14px', marginBottom: '32px' }}>
        Creates all 12 projects in the database. Run once, then remove this page.
      </p>
      {!done ? (
        <button
          onClick={seed}
          disabled={running}
          style={{ background: '#F06A2A', color: '#fff', border: 'none', borderRadius: '4px', padding: '14px 32px', fontSize: '15px', fontWeight: 600, cursor: running ? 'not-allowed' : 'pointer', opacity: running ? 0.7 : 1 }}
        >
          {running ? 'Creating projects…' : 'Create all 12 projects'}
        </button>
      ) : (
        <div style={{ background: '#0F2545', borderRadius: '6px', padding: '20px 24px', color: '#7FCFE3', fontSize: '14px', fontWeight: 600 }}>
          Done! Remove this page from your app.
        </div>
      )}
      {log.length > 0 && (
        <ul style={{ marginTop: '24px', listStyle: 'none', padding: 0 }}>
          {log.map((l, i) => (
            <li key={i} style={{ fontSize: '13px', color: l.startsWith('✓') ? '#2A9BB8' : '#F06A2A', padding: '4px 0' }}>{l}</li>
          ))}
        </ul>
      )}
    </div>
  );
}
