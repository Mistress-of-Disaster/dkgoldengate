import { Link } from 'react-router-dom';

const S = {
  eyebrow: {
    fontFamily: 'DM Sans, sans-serif',
    fontSize: '13px',
    fontWeight: 600,
    letterSpacing: '0.14em',
    textTransform: 'uppercase',
    color: '#F06A2A',
    marginBottom: '20px',
    display: 'block',
  },
  sectionLabel: {
    fontFamily: 'DM Sans, sans-serif',
    fontSize: '11px',
    fontWeight: 600,
    letterSpacing: '0.14em',
    textTransform: 'uppercase',
    color: '#97A2AF',
    marginBottom: '16px',
    display: 'block',
  },
};

const PILLARS = [
  {
    number: '01',
    label: 'Safety first',
    title: 'Tangible assets. Personally vetted developers.',
    img: 'https://media.base44.com/images/public/6a2feb671c52d1dd97abea29/9b2566b62_investor_0.jpg',
    body: [
      'Every deal is secured by real property. We place a lien on both the subject property and any collateral the developer provides — so your investment is backed by tangible assets, not just a promise.',
      "On top of that, every developer we work with is personally vetted. We know them. We know their track record. We don't take on deals we're not confident in.",
    ],
  },
  {
    number: '02',
    label: 'Strong returns',
    title: 'Reward that reflects the reality.',
    img: 'https://media.base44.com/images/public/6a2feb671c52d1dd97abea29/65ab89039_investor_1.webp',
    body: [
      'Private real estate lending offers returns that are difficult to match in mainstream markets. Yes, this type of lending carries more risk than a savings account or index fund.',
      'But that risk is mitigated by real collateral, careful developer selection, and our hands-on oversight of every deal from start to finish. The reward reflects the reality.',
    ],
  },
  {
    number: '03',
    label: 'Full transparency',
    title: 'No black boxes. Ever.',
    img: 'https://media.base44.com/images/public/6a2feb671c52d1dd97abea29/1e14d5e87_investor__2_.png',
    body: [
      "You choose which deals to invest in. Before you commit a single dollar, you'll know the property, the developer, the project plan, and the exit strategy.",
      "There are no black boxes here. It's your money — you should know exactly where it's going and why.",
    ],
  },
];

export default function Investors() {
  return (
    <div>
      {/* HERO — text left, wide panoramic image below */}
      <section style={{ background: '#0A1A33', paddingTop: '160px', paddingBottom: '0' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '0 32px' }}>
          <div style={{ maxWidth: '560px', paddingBottom: '56px' }}>
            <span style={S.eyebrow}>For investors</span>
            <h1 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: 'clamp(36px, 5vw, 60px)', lineHeight: 1.1, color: '#FFFFFF', marginBottom: '20px' }}>
              Invest in real estate.
            </h1>
            <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '18px', lineHeight: 1.6, color: 'rgba(255,255,255,0.65)' }}>
              With full transparency, maximum safety, and unparalleled returns.
            </p>
          </div>
        </div>
        {/* Wide panoramic image — bleeds to edges within max container */}
        <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '0 32px' }}>
          <div style={{ borderRadius: '8px 8px 0 0', overflow: 'hidden' }}>
            <img
              src="https://base44.app/api/apps/69b82174571b99319d3f3dbc/files/mp/public/69b82174571b99319d3f3dbc/93be35f3b_invrstor_hero.png"
              alt="Residential real estate neighborhood aerial"
              style={{ width: '100%', height: '420px', objectFit: 'cover', display: 'block' }}
            />
          </div>
        </div>
      </section>

      {/* WHAT YOU'RE INVESTING IN — centered narrow text */}
      <section style={{ background: '#FFFFFF', padding: '100px 0' }}>
        <div style={{ maxWidth: '740px', margin: '0 auto', padding: '0 32px' }}>
          <span style={S.sectionLabel}>What you're investing in</span>
          <h2 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: 'clamp(28px, 3.5vw, 48px)', color: '#0A1A33', lineHeight: 1.15, marginBottom: '28px' }}>
            Real property.<br />Real exits. Real timelines.
          </h2>
          <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '17px', lineHeight: 1.7, color: '#4B5563', marginBottom: '20px' }}>
            Real estate was, is, and will always be one of the safest investments on this planet. If crypto gives you sleepless nights, real estate might be the answer.
          </p>
          <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '17px', lineHeight: 1.7, color: '#4B5563', marginBottom: '20px' }}>
            Your capital funds short-term residential real estate projects — fix-and-flip renovations and new construction — across the United States. These are <strong style={{ color: '#0A1A33' }}>active, time-bound deals with clear exit strategies</strong>: either a property sale or a refinance into a DSCR loan.
          </p>
          <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '17px', lineHeight: 1.7, color: '#4B5563', marginBottom: '48px' }}>
            You're not locked in for years. Most investments are repaid within twelve months. And unlike real estate funds or REITs, <strong style={{ color: '#0A1A33' }}>you know exactly which deal your money is in</strong>.
          </p>

          {/* Dark quote block */}
          <div style={{ background: '#0F2545', borderRadius: '8px', padding: '36px 40px' }}>
            <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '17px', lineHeight: 1.7, color: 'rgba(255,255,255,0.85)', margin: 0 }}>
              DK Goldengate is a boutique operation. Our investor network is intentionally small and personal — we know our investors by name, and that creates a level of mutual accountability that simply doesn't exist in larger funds.
            </p>
          </div>
        </div>
      </section>

      {/* THREE PILLARS — white bg, images above cards */}
      <section style={{ background: '#FFFFFF', padding: '80px 0 60px', borderTop: '1px solid #ECEFF3' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '0 32px' }}>
          <div style={{ marginBottom: '56px' }}>
            <span style={S.sectionLabel}>Three pillars</span>
            <h2 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: 'clamp(28px, 3.5vw, 48px)', color: '#0A1A33', lineHeight: 1.15 }}>
              Why invest with DK Goldengate?
            </h2>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '28px' }} className="grid-cols-3-1">
            {PILLARS.map((p) => (
              <div key={p.number}>
                <div style={{ borderRadius: '6px', overflow: 'hidden', marginBottom: '24px' }}>
                  <img src={p.img} alt={p.title} style={{ width: '100%', height: '240px', objectFit: 'cover', display: 'block' }} />
                </div>
                <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '10px', fontWeight: 700, letterSpacing: '0.14em', textTransform: 'uppercase', color: '#97A2AF', marginBottom: '10px' }}>
                  {p.number} · {p.label}
                </div>
                <h3 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: '22px', color: '#0A1A33', lineHeight: 1.2, marginBottom: '16px' }}>{p.title}</h3>
                {p.body.map((para, i) => (
                  <p key={i} style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '14px', lineHeight: 1.7, color: '#4B5563', marginBottom: '12px' }}>{para}</p>
                ))}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* MINIMUM INVESTMENT — orange top border, 2-col: text + $50K card */}
      <section style={{ background: '#FFFFFF', padding: '80px 0', borderTop: '3px solid #F06A2A' }}>
        <div style={{ maxWidth: '900px', margin: '0 auto', padding: '0 32px' }}>
          <div style={{ border: '1px solid #DCE2EA', borderRadius: '8px', padding: '48px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '48px', alignItems: 'center' }} className="grid-cols-hero">
            <div>
              <span style={S.sectionLabel}>Minimum investment</span>
              <h2 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: 'clamp(24px, 3vw, 36px)', color: '#0A1A33', lineHeight: 1.15, marginBottom: '20px' }}>
                Who this is for.
              </h2>
              <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '16px', lineHeight: 1.7, color: '#4B5563', margin: 0 }}>
                If you're looking to put your capital to work in real estate, we'd love to have a conversation. We work with investors who are ready to deploy a minimum of <strong style={{ color: '#0A1A33' }}>$50,000</strong> into individual deals.
              </p>
            </div>
            <div style={{ position: 'relative', borderRadius: '6px', overflow: 'hidden' }}>
              <img
                src="https://media.base44.com/images/public/6a2feb671c52d1dd97abea29/0f627d1e6_investor.png"
                alt="Investors"
                style={{ width: '100%', height: '160px', objectFit: 'cover', display: 'block' }}
              />
              <div style={{ position: 'absolute', inset: 0, background: 'rgba(10,26,51,0.65)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: '6px' }}>
                <div style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: '40px', color: '#FFFFFF', lineHeight: 1 }}>$50K</div>
                <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '11px', fontWeight: 600, letterSpacing: '0.14em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.55)' }}>Minimum per deal</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA — "Interested in learning more?" left + 3 stacked buttons right */}
      <section style={{ background: '#F6F8FA', padding: '48px 0', borderTop: '1px solid #DCE2EA' }}>
        <div style={{ maxWidth: '900px', margin: '0 auto', padding: '0 32px' }}>
          <div style={{ background: '#0F2545', borderRadius: '8px', padding: '48px 52px' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '40px', alignItems: 'start' }} className="grid-cols-hero">
              <div>
                <h3 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: 'clamp(20px, 2.5vw, 28px)', color: '#FFFFFF', lineHeight: 1.2, marginBottom: '12px' }}>
                  Interested in learning more?
                </h3>
                <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '14px', lineHeight: 1.65, color: 'rgba(255,255,255,0.5)', margin: 0 }}>
                  Reach out to start a confidential conversation about how DK Goldengate can put your capital to work.
                </p>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                <a href="mailto:dellyinvests@dkgoldengate.com" style={{ background: '#7FCFE3', color: '#0A1A33', fontFamily: 'DM Sans, sans-serif', fontSize: '14px', fontWeight: 700, textDecoration: 'none', padding: '13px 20px', borderRadius: '4px', textAlign: 'center' }}>
                  dellyinvests@dkgoldengate.com
                </a>
                <a href="https://calendar.google.com/calendar/appointments/schedules/AcZssZ2RR4bbnI4HKaSNmo-S8k16p1x_X5V0IQizHfQ9x1QM_gilna503I8efwnHPgTy2_8CwCjd9290?gv=true" target="_blank" rel="noopener noreferrer" style={{ background: 'transparent', color: '#7FCFE3', fontFamily: 'DM Sans, sans-serif', fontSize: '14px', fontWeight: 500, textDecoration: 'none', padding: '13px 20px', borderRadius: '4px', border: '1px solid rgba(127,207,227,0.3)', textAlign: 'center' }}>
                  Book an appointment
                </a>
                <a href="tel:+19256839794" style={{ background: 'transparent', color: 'rgba(255,255,255,0.55)', fontFamily: 'DM Sans, sans-serif', fontSize: '14px', fontWeight: 500, textDecoration: 'none', padding: '13px 20px', borderRadius: '4px', border: '1px solid rgba(255,255,255,0.15)', textAlign: 'center' }}>
                  (925) 683-9794
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}