import { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Navigate } from 'react-router-dom';
import { Plus, Pencil, Trash2, X, Check, Upload, Loader2 } from 'lucide-react';

const EMPTY = {
  name: '', region: '', property_type: '', strategy: '', funding_type: '',
  status: 'Active', featured: false, cover_image_url: '',
  image_urls: [], video_url: '', location_city: '', location_state: '',
  description: '', sort_order: 0,
};

const inputStyle = { width: '100%', fontFamily: 'DM Sans, sans-serif', fontSize: '15px', color: '#0A1A33', background: '#F6F8FA', border: '1px solid #DCE2EA', borderRadius: '4px', padding: '10px 14px', boxSizing: 'border-box' };

function FieldLabel({ label, children }) {
  return (
    <div style={{ marginBottom: '20px' }}>
      <label style={{ display: 'block', fontFamily: 'DM Sans, sans-serif', fontSize: '12px', fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: '#97A2AF', marginBottom: '6px' }}>{label}</label>
      {children}
    </div>
  );
}

function ProjectForm({ initial, onSave, onCancel }) {
  const [form, setForm] = useState({ ...EMPTY, ...initial, image_urls: initial?.image_urls || [] });
  const [saving, setSaving] = useState(false);
  const [uploadingCover, setUploadingCover] = useState(false);
  const [uploadingGallery, setUploadingGallery] = useState(false);
  const coverInputRef = useRef(null);
  const galleryInputRef = useRef(null);

  const set = (key, val) => setForm(f => ({ ...f, [key]: val }));

  const uploadCover = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploadingCover(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    set('cover_image_url', file_url);
    setUploadingCover(false);
    e.target.value = '';
  };

  const uploadGallery = async (e) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;
    setUploadingGallery(true);
    for (const file of files) {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setForm(f => ({ ...f, image_urls: [...(f.image_urls || []), file_url] }));
    }
    setUploadingGallery(false);
    e.target.value = '';
  };

  const handleSave = async () => {
    setSaving(true);
    await onSave({ ...form, sort_order: Number(form.sort_order) || 0 });
    setSaving(false);
  };

  return (
    <div style={{ background: '#FFFFFF', border: '1px solid #DCE2EA', borderRadius: '8px', padding: '40px', marginBottom: '40px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '32px' }}>
        <h2 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: '24px', color: '#0A1A33' }}>
          {initial?.id ? `Edit: ${initial.name}` : 'New Project'}
        </h2>
        <button onClick={onCancel} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#97A2AF' }}><X size={20} /></button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 32px' }} className="grid-cols-hero">
        <div>
          <FieldLabel label="Name *">
            <input style={inputStyle} value={form.name} onChange={e => set('name', e.target.value)} />
          </FieldLabel>
          <FieldLabel label="Region">
            <select style={inputStyle} value={form.region} onChange={e => set('region', e.target.value)}>
              <option value="">— Select —</option>
              {['South','West Coast','East Coast','Midwest','Great Lakes','Northwest'].map(v => <option key={v}>{v}</option>)}
            </select>
          </FieldLabel>
          <FieldLabel label="Property Type">
            <select style={inputStyle} value={form.property_type} onChange={e => set('property_type', e.target.value)}>
              <option value="">— Select —</option>
              {['Single-family','Multifamily','Mixed-use'].map(v => <option key={v}>{v}</option>)}
            </select>
          </FieldLabel>
          <FieldLabel label="Strategy">
            <select style={inputStyle} value={form.strategy} onChange={e => set('strategy', e.target.value)}>
              <option value="">— Select —</option>
              {['Fix & Flip','New Construction'].map(v => <option key={v}>{v}</option>)}
            </select>
          </FieldLabel>
          <FieldLabel label="Funding Type">
            <select style={inputStyle} value={form.funding_type} onChange={e => set('funding_type', e.target.value)}>
              <option value="">— Select —</option>
              {['Gap funding','Whole-deal funding'].map(v => <option key={v}>{v}</option>)}
            </select>
          </FieldLabel>
          <FieldLabel label="Status">
            <select style={inputStyle} value={form.status} onChange={e => set('status', e.target.value)}>
              {['Active','Completed','Archived'].map(v => <option key={v}>{v}</option>)}
            </select>
          </FieldLabel>
          <FieldLabel label="Location City">
            <input style={inputStyle} value={form.location_city} onChange={e => set('location_city', e.target.value)} />
          </FieldLabel>
          <FieldLabel label="Location State">
            <input style={inputStyle} value={form.location_state} onChange={e => set('location_state', e.target.value)} />
          </FieldLabel>
          <FieldLabel label="Sort Order">
            <input type="number" style={inputStyle} value={form.sort_order} onChange={e => set('sort_order', e.target.value)} />
          </FieldLabel>
          <FieldLabel label="Featured on homepage">
            <label style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer' }}>
              <input type="checkbox" checked={form.featured} onChange={e => set('featured', e.target.checked)} style={{ width: '18px', height: '18px' }} />
              <span style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '15px', color: '#0A1A33' }}>Show on homepage</span>
            </label>
          </FieldLabel>
        </div>

        <div>
          <FieldLabel label="Cover Image">
            <input ref={coverInputRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={uploadCover} />
            {form.cover_image_url ? (
              <div style={{ position: 'relative', marginBottom: '8px' }}>
                <img src={form.cover_image_url} alt="" style={{ width: '100%', height: '180px', objectFit: 'cover', borderRadius: '4px', border: '1px solid #DCE2EA', display: 'block' }} />
                <button onClick={() => set('cover_image_url', '')} style={{ position: 'absolute', top: '8px', right: '8px', background: 'rgba(0,0,0,0.6)', border: 'none', borderRadius: '50%', width: '28px', height: '28px', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}><X size={14} color="#fff" /></button>
              </div>
            ) : (
              <button onClick={() => coverInputRef.current.click()} disabled={uploadingCover} style={{ width: '100%', height: '100px', background: '#F6F8FA', border: '2px dashed #DCE2EA', borderRadius: '4px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', fontFamily: 'DM Sans, sans-serif', fontSize: '14px', color: '#97A2AF' }}>
                {uploadingCover ? <><Loader2 size={16} /> Uploading…</> : <><Upload size={16} /> Upload cover image</>}
              </button>
            )}
            {form.cover_image_url && (
              <button onClick={() => coverInputRef.current.click()} disabled={uploadingCover} style={{ marginTop: '6px', background: '#F6F8FA', color: '#4B5563', fontFamily: 'DM Sans, sans-serif', fontSize: '13px', border: '1px solid #DCE2EA', borderRadius: '4px', padding: '7px 14px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '6px' }}>
                {uploadingCover ? <><Loader2 size={13} /> Uploading…</> : <><Upload size={13} /> Replace image</>}
              </button>
            )}
          </FieldLabel>

          <FieldLabel label="Additional Images">
            <input ref={galleryInputRef} type="file" accept="image/*" multiple style={{ display: 'none' }} onChange={uploadGallery} />
            <button onClick={() => galleryInputRef.current.click()} disabled={uploadingGallery} style={{ width: '100%', background: '#F6F8FA', border: '2px dashed #DCE2EA', borderRadius: '4px', padding: '14px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', fontFamily: 'DM Sans, sans-serif', fontSize: '14px', color: '#97A2AF', marginBottom: '10px' }}>
              {uploadingGallery ? <><Loader2 size={16} /> Uploading…</> : <><Upload size={16} /> Upload photos (select multiple)</>}
            </button>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '8px' }}>
              {(form.image_urls || []).map((url, i) => (
                <div key={i} style={{ position: 'relative' }}>
                  <img src={url} alt="" style={{ width: '100%', height: '70px', objectFit: 'cover', borderRadius: '4px', border: '1px solid #DCE2EA', display: 'block' }} />
                  <button onClick={() => setForm(f => ({ ...f, image_urls: f.image_urls.filter((_, idx) => idx !== i) }))} style={{ position: 'absolute', top: '4px', right: '4px', background: 'rgba(0,0,0,0.6)', border: 'none', borderRadius: '50%', width: '22px', height: '22px', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}><X size={12} color="#fff" /></button>
                </div>
              ))}
            </div>
          </FieldLabel>

          <FieldLabel label="Video URL (YouTube or Vimeo)">
            <input style={inputStyle} placeholder="https://youtube.com/watch?v=..." value={form.video_url} onChange={e => set('video_url', e.target.value)} />
          </FieldLabel>
          <FieldLabel label="Description">
            <textarea style={{ ...inputStyle, height: '120px', resize: 'vertical' }} value={form.description} onChange={e => set('description', e.target.value)} />
          </FieldLabel>
        </div>
      </div>

      <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end', marginTop: '8px', borderTop: '1px solid #ECEFF3', paddingTop: '24px' }}>
        <button onClick={onCancel} style={{ background: 'transparent', color: '#4B5563', fontFamily: 'DM Sans, sans-serif', fontSize: '14px', fontWeight: 500, border: '1px solid #DCE2EA', borderRadius: '4px', padding: '10px 24px', cursor: 'pointer' }}>Cancel</button>
        <button onClick={handleSave} disabled={saving || !form.name} style={{ display: 'flex', alignItems: 'center', gap: '8px', background: saving ? '#97A2AF' : '#0A1A33', color: '#FFFFFF', fontFamily: 'DM Sans, sans-serif', fontSize: '14px', fontWeight: 600, border: 'none', borderRadius: '4px', padding: '10px 28px', cursor: saving ? 'not-allowed' : 'pointer' }}>
          <Check size={16} /> {saving ? 'Saving…' : 'Save project'}
        </button>
      </div>
    </div>
  );
}

export default function ProjectsAdmin() {
  const { user } = useAuth();
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);

  useEffect(() => { load(); }, []);

  if (user && user.role !== 'admin') return <Navigate to="/" replace />;

  const load = async () => {
    setLoading(true);
    const data = await base44.entities.Project.list('sort_order', 200);
    setProjects(data);
    setLoading(false);
  };

  const handleSave = async (payload) => {
    if (editing === 'new') {
      await base44.entities.Project.create(payload);
    } else {
      await base44.entities.Project.update(editing.id, payload);
    }
    setEditing(null);
    load();
  };

  const remove = async (id) => {
    if (!confirm('Delete this project?')) return;
    await base44.entities.Project.delete(id);
    load();
  };

  return (
    <div style={{ minHeight: '100vh', background: '#F6F8FA', paddingTop: '100px', paddingBottom: '80px' }}>
      <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '0 32px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '40px' }}>
          <div>
            <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '11px', fontWeight: 600, letterSpacing: '0.14em', textTransform: 'uppercase', color: '#97A2AF', marginBottom: '8px' }}>Admin</div>
            <h1 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: '36px', color: '#0A1A33' }}>Projects</h1>
          </div>
          <button onClick={() => setEditing('new')} style={{ display: 'flex', alignItems: 'center', gap: '8px', background: '#F06A2A', color: '#FFFFFF', fontFamily: 'DM Sans, sans-serif', fontSize: '14px', fontWeight: 600, border: 'none', borderRadius: '4px', padding: '12px 24px', cursor: 'pointer' }}>
            <Plus size={16} /> Add project
          </button>
        </div>

        {editing !== null && (
          <ProjectForm
            initial={editing === 'new' ? null : editing}
            onSave={handleSave}
            onCancel={() => setEditing(null)}
          />
        )}

        {loading ? (
          <div style={{ textAlign: 'center', padding: '60px 0', fontFamily: 'DM Sans, sans-serif', fontSize: '15px', color: '#97A2AF' }}>Loading…</div>
        ) : projects.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '60px 0', fontFamily: 'DM Sans, sans-serif', fontSize: '15px', color: '#97A2AF' }}>No projects yet. Click "Add project" to create one.</div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {projects.map(p => (
              <div key={p.id} style={{ background: '#FFFFFF', border: '1px solid #DCE2EA', borderRadius: '6px', padding: '20px 24px', display: 'flex', alignItems: 'center', gap: '20px' }}>
                {p.cover_image_url && (
                  <img src={p.cover_image_url} alt="" style={{ width: '72px', height: '52px', objectFit: 'cover', borderRadius: '4px', flexShrink: 0 }} />
                )}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: '17px', color: '#0A1A33', marginBottom: '4px' }}>{p.name}</div>
                  <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '13px', color: '#97A2AF' }}>
                    {[p.region, p.strategy, p.status].filter(Boolean).join(' · ')}
                    {p.featured && <span style={{ marginLeft: '10px', background: '#FFF0E8', color: '#C04A0E', fontSize: '11px', fontWeight: 600, padding: '2px 8px', borderRadius: '3px' }}>Featured</span>}
                  </div>
                </div>
                <div style={{ display: 'flex', gap: '8px', flexShrink: 0 }}>
                  <button onClick={() => setEditing(p)} style={{ display: 'flex', alignItems: 'center', gap: '6px', background: '#F6F8FA', color: '#0A1A33', fontFamily: 'DM Sans, sans-serif', fontSize: '13px', fontWeight: 500, border: '1px solid #DCE2EA', borderRadius: '4px', padding: '8px 16px', cursor: 'pointer' }}>
                    <Pencil size={14} /> Edit
                  </button>
                  <button onClick={() => remove(p.id)} style={{ display: 'flex', alignItems: 'center', gap: '6px', background: '#FFF0F0', color: '#C04A0E', fontFamily: 'DM Sans, sans-serif', fontSize: '13px', fontWeight: 500, border: '1px solid #FCDADA', borderRadius: '4px', padding: '8px 16px', cursor: 'pointer' }}>
                    <Trash2 size={14} /> Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
