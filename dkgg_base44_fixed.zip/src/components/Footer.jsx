import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer style={{ background: '#0A1A33', color: '#FFFFFF', paddingTop: '80px', paddingBottom: '48px' }}>
      <div style={{ maxWidth: '1280px', margin: '0 auto', padding: '0 32px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '48px', paddingBottom: '64px', borderBottom: '1px solid rgba(255,255,255,0.08)' }}>

          {/* Brand column */}
          <div style={{ gridColumn: 'span 2' }} className="col-span-2 sm:col-span-1">
            <div style={{ marginBottom: '20px' }}>
              <div style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: '18px', color: '#FFFFFF' }}>DK Goldengate</div>
              <div style={{ fontFamily: 'DM Sans, sans-serif', fontWeight: 400, fontSize: '11px', letterSpacing: '0.12em', textTransform: 'uppercase', color: '#7FCFE3' }}>Ventures LLC</div>
            </div>
            <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '14px', lineHeight: 1.7, color: 'rgba(255,255,255,0.55)', maxWidth: '280px' }}>
              A boutique private real estate lender. Woman- and minority-owned. On a first-name basis with every developer we work with.
            </p>
          </div>

          {/* Services */}
          <div>
            <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '11px', fontWeight: 600, letterSpacing: '0.12em', textTransform: 'uppercase', color: '#7FCFE3', marginBottom: '20px' }}>Services</div>
            {[
              { label: 'For Developers', href: '/developers' },
              { label: 'For Investors', href: '/investors' },
              { label: 'The Deal Machine', href: '/deal-machine' },
            ].map(l => (
              <Link key={l.href} to={l.href} style={{ display: 'block', color: 'rgba(255,255,255,0.55)', fontFamily: 'DM Sans, sans-serif', fontSize: '15px', textDecoration: 'none', marginBottom: '12px', transition: 'color 0.2s' }}>
                {l.label}
              </Link>
            ))}
          </div>

          {/* Company */}
          <div>
            <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '11px', fontWeight: 600, letterSpacing: '0.12em', textTransform: 'uppercase', color: '#7FCFE3', marginBottom: '20px' }}>Company</div>
            {[
              { label: 'How it works', href: '/how-it-works' },
              { label: 'Projects', href: '/projects' },
            ].map(l => (
              <Link key={l.href} to={l.href} style={{ display: 'block', color: 'rgba(255,255,255,0.55)', fontFamily: 'DM Sans, sans-serif', fontSize: '15px', textDecoration: 'none', marginBottom: '12px', transition: 'color 0.2s' }}>
                {l.label}
              </Link>
            ))}
          </div>

          {/* Contact */}
          <div>
            <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '11px', fontWeight: 600, letterSpacing: '0.12em', textTransform: 'uppercase', color: '#7FCFE3', marginBottom: '20px' }}>Contact</div>
            <a href="mailto:dellyinvests@dkgoldengate.com" style={{ display: 'block', color: 'rgba(255,255,255,0.55)', fontFamily: 'DM Sans, sans-serif', fontSize: '14px', textDecoration: 'none', marginBottom: '12px', wordBreak: 'break-word' }}>
              dellyinvests@dkgoldengate.com
            </a>
            <a href="tel:+19256839794" style={{ display: 'block', color: 'rgba(255,255,255,0.55)', fontFamily: 'DM Sans, sans-serif', fontSize: '15px', textDecoration: 'none', marginBottom: '12px' }}>
              (925) 683-9794
            </a>
            <div style={{ color: 'rgba(255,255,255,0.35)', fontFamily: 'DM Sans, sans-serif', fontSize: '13px', marginTop: '8px' }}>
              San Francisco Bay Area, CA
            </div>
          </div>
        </div>

        <div style={{ paddingTop: '32px', display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'center', gap: '16px' }}>
          <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '13px', color: 'rgba(255,255,255,0.3)' }}>
            © 2026 DK Goldengate Ventures LLC. All rights reserved.
          </p>
          <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '13px', color: 'rgba(255,255,255,0.3)' }}>
            Private lending · Residential real estate · Nationwide
          </p>
        </div>
      </div>
    </footer>
  );
}