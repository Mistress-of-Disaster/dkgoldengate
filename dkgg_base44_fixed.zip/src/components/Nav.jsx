import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();
  const { user } = useAuth();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  const links = [
    { label: 'Developers', href: '/developers' },
    { label: 'Investors', href: '/investors' },
    { label: 'How it works', href: '/how-it-works' },
    { label: 'Projects', href: '/projects' },
  ];

  const isActive = (href) => location.pathname === href;

  return (
    <header
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100,
        transition: 'background 0.3s, box-shadow 0.3s',
        background: scrolled ? 'rgba(10,26,51,0.96)' : 'linear-gradient(to bottom, rgba(10,26,51,0.75) 0%, transparent 100%)',
        backdropFilter: scrolled ? 'blur(12px)' : 'none',
        boxShadow: scrolled ? '0 1px 0 rgba(255,255,255,0.08)' : 'none',
      }}
    >
      <div style={{ maxWidth: '1280px', margin: '0 auto', padding: '0 32px' }}>
        <nav style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: '72px' }}>
          {/* Logo */}
          <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: '10px', textDecoration: 'none' }}>
            <GGLogo />
            <div>
              <div style={{ color: '#FFFFFF', fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: '15px', lineHeight: 1.1, letterSpacing: '0.01em' }}>DK Goldengate</div>
              <div style={{ color: '#7FCFE3', fontFamily: 'DM Sans, sans-serif', fontWeight: 400, fontSize: '11px', letterSpacing: '0.12em', textTransform: 'uppercase' }}>Ventures LLC</div>
            </div>
          </Link>

          {/* Desktop Links */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '32px' }} className="hidden md:flex">
            {links.map((l) => (
              <Link
                key={l.href}
                to={l.href}
                style={{
                  color: isActive(l.href) ? '#7FCFE3' : 'rgba(255,255,255,0.75)',
                  fontFamily: 'DM Sans, sans-serif',
                  fontSize: '15px',
                  fontWeight: 500,
                  textDecoration: 'none',
                  letterSpacing: '0.01em',
                  transition: 'color 0.2s',
                  borderBottom: isActive(l.href) ? '1px solid #7FCFE3' : '1px solid transparent',
                  paddingBottom: '2px',
                }}
              >
                {l.label}
              </Link>
            ))}
            {user?.role === 'admin' && (
              <Link
                to="/admin/projects"
                style={{
                  color: isActive('/admin/projects') ? '#7FCFE3' : 'rgba(255,255,255,0.5)',
                  fontFamily: 'DM Sans, sans-serif',
                  fontSize: '13px',
                  fontWeight: 500,
                  textDecoration: 'none',
                  letterSpacing: '0.01em',
                  borderBottom: isActive('/admin/projects') ? '1px solid #7FCFE3' : '1px solid transparent',
                  paddingBottom: '2px',
                }}
              >
                Admin
              </Link>
            )}
            <a
              href="mailto:dellyinvests@dkgoldengate.com"
              style={{
                background: '#F06A2A',
                color: '#FFFFFF',
                fontFamily: 'DM Sans, sans-serif',
                fontSize: '14px',
                fontWeight: 600,
                textDecoration: 'none',
                padding: '10px 22px',
                borderRadius: '4px',
                letterSpacing: '0.02em',
                transition: 'background 0.2s',
              }}
            >
              Get in touch
            </a>
          </div>

          {/* Mobile Hamburger */}
          <button
            className="md:hidden"
            onClick={() => setMenuOpen(!menuOpen)}
            style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#FFFFFF', padding: '4px' }}
            aria-label="Toggle menu"
          >
            {menuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </nav>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div style={{ background: '#0A1A33', borderTop: '1px solid rgba(255,255,255,0.08)', padding: '24px 32px' }}>
          {links.map((l) => (
            <Link
              key={l.href}
              to={l.href}
              style={{
                display: 'block',
                color: isActive(l.href) ? '#7FCFE3' : 'rgba(255,255,255,0.8)',
                fontFamily: 'DM Sans, sans-serif',
                fontSize: '17px',
                fontWeight: 500,
                textDecoration: 'none',
                padding: '12px 0',
                borderBottom: '1px solid rgba(255,255,255,0.06)',
              }}
            >
              {l.label}
            </Link>
          ))}
          <a
            href="mailto:dellyinvests@dkgoldengate.com"
            style={{
              display: 'inline-block',
              marginTop: '20px',
              background: '#F06A2A',
              color: '#FFFFFF',
              fontFamily: 'DM Sans, sans-serif',
              fontSize: '15px',
              fontWeight: 600,
              textDecoration: 'none',
              padding: '12px 28px',
              borderRadius: '4px',
            }}
          >
            Get in touch
          </a>
        </div>
      )}
    </header>
  );
}

function GGLogo() {
  return (
    <svg viewBox="0 0 100 52" height="28" fill="none" aria-hidden="true">
      <path d="M3 50 L50 5 L97 50" stroke="#FFFFFF" strokeWidth="5.5" strokeLinecap="square" strokeLinejoin="miter"/>
      <path d="M19 50 L50 22 L81 50" stroke="#7FCFE3" strokeWidth="3" strokeLinecap="square" strokeLinejoin="miter"/>
    </svg>
  );
}