const S = {
  eyebrow: {
    fontFamily: 'DM Sans, sans-serif',
    fontSize: '13px',
    fontWeight: 600,
    letterSpacing: '0.14em',
    textTransform: 'uppercase',
    color: '#7FCFE3',
    marginBottom: '20px',
    display: 'block',
  },
  sectionLabel: {
    fontFamily: 'DM Sans, sans-serif',
    fontSize: '11px',
    fontWeight: 600,
    letterSpacing: '0.14em',
    textTransform: 'uppercase',
    color: '#97A2AF',
    marginBottom: '16px',
    display: 'block',
  },
};

const developerSteps = [
  {
    step: '01',
    title: 'Submit your deal',
    body: 'Share the basics — property address, purchase price, renovation budget, ARV, your experience, and your capital stack. Use the Deal Machine to run preliminary numbers first, then reach out directly.',
  },
  {
    step: '02',
    title: 'We review and underwrite',
    body: 'We evaluate the deal on its merits: the numbers, the location, the developer\'s track record, and the exit strategy. Our process is thorough but efficient — built for residential, not institutional complexity.',
  },
  {
    step: '03',
    title: 'Term sheet and close',
    body: 'If your deal is a fit, we issue a term sheet with our proposed structure. Once agreed, we move to close. Two-week timelines are our standard when deals come in clean.',
  },
  {
    step: '04',
    title: 'Draw schedule and project oversight',
    body: 'Funds are disbursed per an agreed draw schedule tied to project milestones. We stay engaged throughout — not to micromanage, but because we\'re invested in the outcome alongside you.',
  },
];

const investorSteps = [
  {
    step: '01',
    title: 'Reach out and introduce yourself',
    body: 'Send an email or call. Tell us a bit about yourself, your investment background, and what you\'re looking to achieve. We keep our investor network small and relationships personal.',
  },
  {
    step: '02',
    title: 'Review available deals',
    body: 'We share deals as they come in — with full details on the property, the developer, the renovation plan, the projected returns, and the exit timeline. You choose what fits.',
  },
  {
    step: '03',
    title: 'Commit to a deal',
    body: 'Once you\'ve selected a deal, we move to documentation. Your investment is secured by a lien on the subject property. Minimum investment is $50,000 per deal.',
  },
  {
    step: '04',
    title: 'Receive repayment and returns',
    body: 'When the project exits — either through sale or refinance — you receive your principal back plus your agreed return. Most deals resolve within 12 months.',
  },
];

function StepList({ steps, dark = false }) {
  return (
    <div>
      {steps.map((s, i) => (
        <div
          key={s.step}
          style={{
            display: 'grid',
            gridTemplateColumns: '80px 1fr',
            gap: '32px',
            paddingBottom: i < steps.length - 1 ? '48px' : 0,
            marginBottom: i < steps.length - 1 ? '48px' : 0,
            borderBottom: i < steps.length - 1 ? `1px solid ${dark ? 'rgba(255,255,255,0.08)' : '#ECEFF3'}` : 'none',
          }}
        >
          <div style={{ fontFamily: 'PT Serif, Georgia, serif', fontSize: '42px', fontWeight: 700, color: dark ? 'rgba(127,207,227,0.2)' : '#DCE2EA', lineHeight: 1, paddingTop: '4px' }}>{s.step}</div>
          <div>
            <h3 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: '22px', color: dark ? '#FFFFFF' : '#0A1A33', marginBottom: '12px' }}>{s.title}</h3>
            <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '16px', lineHeight: 1.7, color: dark ? 'rgba(255,255,255,0.55)' : '#4B5563' }}>{s.body}</p>
          </div>
        </div>
      ))}
    </div>
  );
}

export default function HowItWorks() {
  return (
    <div>
      {/* HERO */}
      <section style={{ background: '#0A1A33', paddingTop: '160px', paddingBottom: '120px' }}>
        <div style={{ maxWidth: '900px', margin: '0 auto', padding: '0 32px' }}>
          <span style={S.eyebrow}>Process</span>
          <h1 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: 'clamp(36px, 5vw, 64px)', lineHeight: 1.1, color: '#FFFFFF', marginBottom: '28px' }}>
            How it works.
          </h1>
          <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '19px', lineHeight: 1.6, color: 'rgba(255,255,255,0.6)', maxWidth: '580px' }}>
            Whether you're a developer looking for funding or an investor looking to deploy capital, the process is straightforward, transparent, and personal.
          </p>
        </div>
      </section>

      {/* FOR DEVELOPERS */}
      <section style={{ background: '#FFFFFF', padding: '120px 0' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '0 32px' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '80px' }} className="grid-cols-hero">
            <div>
              <span style={S.sectionLabel}>For developers</span>
              <h2 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: 'clamp(26px, 3vw, 40px)', lineHeight: 1.15, color: '#0A1A33', marginBottom: '16px' }}>
                How to get funded.
              </h2>
              <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '16px', lineHeight: 1.65, color: '#97A2AF' }}>
                Four steps from first contact to funded deal.
              </p>
            </div>
            <StepList steps={developerSteps} dark={false} />
          </div>
        </div>
      </section>

      {/* FOR INVESTORS */}
      <section style={{ background: '#0F2545', padding: '120px 0' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '0 32px' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '80px' }} className="grid-cols-hero">
            <div>
              <span style={S.eyebrow}>For investors</span>
              <h2 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: 'clamp(26px, 3vw, 40px)', lineHeight: 1.15, color: '#FFFFFF', marginBottom: '16px' }}>
                How to invest.
              </h2>
              <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '16px', lineHeight: 1.65, color: 'rgba(255,255,255,0.45)' }}>
                From introduction to repayment — clear and straightforward.
              </p>
            </div>
            <StepList steps={investorSteps} dark={true} />
          </div>
        </div>
      </section>

      {/* CLOSING NOTE */}
      <section style={{ background: '#F6F8FA', padding: '80px 0', borderTop: '1px solid #DCE2EA' }}>
        <div style={{ maxWidth: '680px', margin: '0 auto', padding: '0 32px', textAlign: 'center' }}>
          <p style={{ fontFamily: 'PT Serif, Georgia, serif', fontSize: 'clamp(18px, 2.5vw, 26px)', lineHeight: 1.55, color: '#0A1A33', fontStyle: 'italic' }}>
            "Every conversation starts the same way: with honesty, no pressure, and a genuine look at whether the fit is right."
          </p>
          <div style={{ marginTop: '24px', fontFamily: 'DM Sans, sans-serif', fontSize: '14px', color: '#97A2AF' }}>
            — Delband "Delly" Kerachi, Founder
          </div>
        </div>
      </section>
    </div>
  );
}