import { useState } from 'react';
import { base44 } from '@/api/base44Client';

const DealSubmission = base44.entities.DealSubmission;

const fmt = v => '$' + Math.round(v).toLocaleString();
const pct = v => (v * 100).toFixed(1) + '%';

export default function DealMachine() {
  const [form, setForm] = useState({
    purchasePrice: '',
    arv: '',
    rehab: '',
    otherCosts: '',
    loanAmount: '',
    dealType: '',
    propertyAddress: '',
  });
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  function analyze() {
    const purchase = parseFloat(form.purchasePrice) || 0;
    const arv      = parseFloat(form.arv) || 0;
    const rehab    = parseFloat(form.rehab) || 0;
    const other    = parseFloat(form.otherCosts) || 0;
    const loan     = parseFloat(form.loanAmount) || 0;

    if (!purchase || !arv || !loan) {
      setError('Please enter at least Purchase price, ARV, and Loan amount.');
      return;
    }
    setError('');

    const totalCost  = purchase + rehab + other;
    const ltv        = loan / arv;
    const ltc        = loan / totalCost;
    const equity     = arv - totalCost;
    const equityPct  = equity / arv;
    const isDeal     = ltv <= 0.80 && equityPct >= 0.10;

    let reason = '';
    if (!isDeal) {
      if (ltv > 0.80) reason = 'Combined LTV exceeds 80% — consider adjusting your loan amount.';
      else if (equityPct < 0.10) reason = 'Equity margin is below 10% — the deal does not meet our minimum buffer.';
      else reason = 'Equity position is too thin for this deal.';
    }

    setResult({ isDeal, ltv, ltc, equity, equityPct, reason, purchase, arv, rehab, other, loan });
    setSubmitted(false);
    setTimeout(() => document.getElementById('dm-result')?.scrollIntoView({ behavior: 'smooth', block: 'nearest' }), 60);
  }

  async function submitDeal() {
    if (!result || submitting) return;
    setSubmitting(true);
    try {
      await DealSubmission.create({
        property_address: form.propertyAddress || 'Not provided',
        deal_type: form.dealType === 'full' ? 'Full deal (1st position)' : form.dealType === 'bridge' ? 'Bridge / 2nd position' : undefined,
        purchase_price: result.purchase,
        arv: result.arv,
        rehab_budget: result.rehab,
        other_costs: result.other,
        loan_amount: result.loan,
        ltv: result.ltv,
        ltc: result.ltc,
        equity: result.equity,
        equity_pct: result.equityPct,
        verdict: result.isDeal ? 'Deal' : 'No Deal',
        status: 'New',
      });
      setSubmitted(true);
    } catch (e) {
      setError('Could not save submission. Please email us directly.');
    } finally {
      setSubmitting(false);
    }
  }

  const inputStyle = {
    width: '100%',
    background: 'rgba(255,255,255,0.06)',
    border: '1px solid rgba(255,255,255,0.12)',
    borderRadius: '8px',
    padding: '12px 14px',
    color: '#fff',
    fontFamily: 'DM Sans, sans-serif',
    fontSize: '15px',
    outline: 'none',
    boxSizing: 'border-box',
  };
  const labelStyle = {
    display: 'block',
    fontFamily: 'DM Sans, sans-serif',
    fontSize: '11px',
    fontWeight: 600,
    letterSpacing: '0.12em',
    textTransform: 'uppercase',
    color: 'rgba(255,255,255,0.45)',
    marginBottom: '6px',
  };

  return (
    <div>
      {/* HERO */}
      <section style={{
        background: 'linear-gradient(160deg, #060E1E 0%, #0A1A33 40%, #0F2545 100%)',
        minHeight: '60vh',
        display: 'flex',
        alignItems: 'center',
        paddingTop: '120px',
        paddingBottom: '64px',
        position: 'relative',
        overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', inset: 0,
          backgroundImage: 'linear-gradient(rgba(127,207,227,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(127,207,227,0.03) 1px, transparent 1px)',
          backgroundSize: '80px 80px',
          pointerEvents: 'none',
        }} />
        <div style={{ maxWidth: '1000px', margin: '0 auto', padding: '0 32px', position: 'relative', zIndex: 1 }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '10px', marginBottom: '32px' }}>
            <div style={{ width: '28px', height: '2px', background: '#F06A2A' }} />
            <span style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '12px', fontWeight: 600, letterSpacing: '0.18em', textTransform: 'uppercase', color: '#7FCFE3' }}>
              Private real estate lending · Powered by Sheldon
            </span>
          </div>
          <h1 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: 'clamp(42px, 7vw, 80px)', lineHeight: 1.05, color: '#fff', marginBottom: '8px' }}>
            Want to know how good
          </h1>
          <h1 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: 'clamp(42px, 7vw, 80px)', lineHeight: 1.05, color: '#7FCFE3', marginBottom: '32px' }}>
            your deal really is?
          </h1>
          <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 'clamp(16px, 1.8vw, 20px)', lineHeight: 1.65, color: 'rgba(255,255,255,0.74)', maxWidth: '600px', margin: '0 auto 40px' }}>
            Put it to the test. If the Deal Machine says yes, submit your complete package and get it reviewed within four business days. We're looking forward to working with you.
          </p>
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px', flexWrap: 'wrap', justifyContent: 'center', marginBottom: '56px' }}>
            <a href="#deal-machine" style={{ display: 'inline-flex', alignItems: 'center', gap: '8px', background: '#7FCFE3', color: '#0A1A33', fontFamily: 'DM Sans, sans-serif', fontSize: '16px', fontWeight: 700, textDecoration: 'none', padding: '16px 30px', borderRadius: '10px' }}>
              <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><path d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
              Run the Deal Machine
            </a>
            <a href="#apply" style={{ display: 'inline-flex', alignItems: 'center', gap: '8px', background: 'transparent', color: '#FFFFFF', fontFamily: 'DM Sans, sans-serif', fontSize: '16px', fontWeight: 700, textDecoration: 'none', padding: '16px 30px', borderRadius: '10px', border: '1px solid rgba(255,255,255,0.22)' }}>
              Submit your deal →
            </a>
          </div>
          {/* Trust strip */}
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '32px', flexWrap: 'wrap', justifyContent: 'center', padding: '14px 28px', borderRadius: '999px', background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)' }}>
            {[
              { icon: <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M8 1v14M3 6l5-5 5 5"/></svg>, text: <><strong style={{ color: '#fff' }}>4-day</strong> response window</> },
              { icon: <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="8" cy="8" r="6"/><path d="M8 4v4l3 2"/></svg>, text: <>Close in as little as <strong style={{ color: '#fff' }}>2 weeks</strong></> },
              { icon: <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M8 1l2 4 5 .7-3.6 3.5.9 5L8 11.8 3.7 14.2l.9-5L1 5.7l5-.7L8 1z"/></svg>, text: <>Built by developers, for <strong style={{ color: '#fff' }}>developers</strong></> },
            ].map((item, i) => (
              <span key={i} style={{ display: 'inline-flex', alignItems: 'center', gap: '8px', fontSize: '12.5px', color: 'rgba(255,255,255,0.7)', fontFamily: 'DM Sans, sans-serif', fontWeight: 500 }}>
                <span style={{ color: '#7FCFE3' }}>{item.icon}</span>
                {item.text}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* THE PROCESS */}
      <section style={{ background: '#FFFFFF', padding: '72px 0' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '0 32px' }}>
          <div style={{ marginBottom: '48px' }}>
            <span style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '11px', fontWeight: 600, letterSpacing: '0.14em', textTransform: 'uppercase', color: '#97A2AF', marginBottom: '16px', display: 'block' }}>The process</span>
            <h2 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: 'clamp(28px, 3.5vw, 48px)', color: '#0A1A33', lineHeight: 1.15 }}>
              Straightforward.<br />No surprises.
            </h2>
            <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '17px', lineHeight: 1.65, color: '#4B5563', marginTop: '16px', maxWidth: '560px' }}>
              We love working with developers who come prepared. Run your numbers, submit a complete package, and we'll review it within four business days.
            </p>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '28px' }} className="grid-cols-3-1">
            {[
              {
                num: '01',
                icon: <svg width="22" height="22" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="5" y="2" width="14" height="20" rx="2"/><line x1="9" y1="7" x2="15" y2="7"/><line x1="9" y1="11" x2="15" y2="11"/><line x1="9" y1="15" x2="12" y2="15"/></svg>,
                title: 'Run your numbers',
                body: 'Use the Deal Machine below. Enter your key numbers — purchase price, rehab budget, loan amount, and other costs. If the deal works on a conservative ARV, it\'s worth submitting.',
              },
              {
                num: '02',
                icon: <svg width="22" height="22" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9 12l2 2 4-4"/></svg>,
                title: 'Submit a complete package',
                body: 'Complete the intake form with your deal details, entity documents, financial statements, and verified experience. A complete submission moves faster.',
              },
              {
                num: '03',
                icon: <svg width="22" height="22" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>,
                title: 'We review and respond',
                body: 'We review your submission and respond within four business days. If we don\'t respond within that window, please consider it a pass and move forward with other options.',
              },
            ].map((step) => (
              <div key={step.num} style={{ background: '#F6F8FA', borderRadius: '8px', padding: '32px 28px', position: 'relative' }}>
                <div style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: '48px', color: 'rgba(10,26,51,0.06)', lineHeight: 1, marginBottom: '16px' }}>{step.num}</div>
                <div style={{ width: '44px', height: '44px', background: '#0F2545', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#7FCFE3', marginBottom: '20px' }}>
                  {step.icon}
                </div>
                <h3 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: '20px', color: '#0A1A33', lineHeight: 1.2, marginBottom: '12px' }}>{step.title}</h3>
                <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '14px', lineHeight: 1.7, color: '#4B5563', margin: 0 }}>{step.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* DEAL MACHINE SECTION */}
      <section style={{ background: '#0A1A33', padding: '80px 0' }} id="deal-machine">
        <div style={{ maxWidth: '1180px', margin: '0 auto', padding: '0 32px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '64px', alignItems: 'start' }}>

          {/* LEFT — rules */}
          <div>
            <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '11px', fontWeight: 600, letterSpacing: '0.16em', textTransform: 'uppercase', color: '#F06A2A', marginBottom: '16px' }}>
              Powered by Sheldon
            </div>
            <h2 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: 'clamp(26px, 3vw, 40px)', lineHeight: 1.15, color: '#fff', marginBottom: '16px' }}>
              The Deal Machine
            </h2>
            <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '16px', lineHeight: 1.7, color: 'rgba(255,255,255,0.55)', marginBottom: '36px' }}>
              Before you submit anything, run your numbers. Enter your purchase price, rehab budget, and loan structure — and get a clear{' '}
              <strong style={{ color: '#46c585' }}>Deal</strong> or <strong style={{ color: '#ec6a6a' }}>No Deal</strong> result based on our underwriting criteria.
            </p>

            <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '10px', fontWeight: 700, letterSpacing: '0.16em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.3)', marginBottom: '16px' }}>
              Better safe than sorry
            </div>

            {[
              { title: 'Minimum 10% margin required', body: 'After all costs — purchase, rehab, financing, holding, selling — projections must still show a minimum 10% margin as a healthy buffer. We don\'t fund deals below this threshold.', gold: false },
              { title: 'Combined LTV capped at 80%', body: 'The combined LTV has to stay under 80% — with gap funding or not. If the leverage is too high, the spread is too thin, and so is the buffer.', gold: false },
              { title: 'Green light? Go straight to the intake.', body: 'A green result takes you directly to the submission form — no starting over, no re-entering data.', gold: true },
            ].map((rule, i) => (
              <div key={i} style={{ display: 'flex', gap: '14px', alignItems: 'start', marginBottom: '20px' }}>
                <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: rule.gold ? '#F06A2A' : '#4FB8D1', marginTop: '7px', flexShrink: 0 }} />
                <div>
                  <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '15px', fontWeight: 700, color: '#fff', marginBottom: '4px', lineHeight: 1.3 }}>{rule.title}</div>
                  <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '14px', lineHeight: 1.6, color: 'rgba(255,255,255,0.45)' }}>{rule.body}</div>
                </div>
              </div>
            ))}
          </div>

          {/* RIGHT — calculator card */}
          <div style={{
            background: 'linear-gradient(160deg, #0F2545 0%, #0A1A33 100%)',
            border: '1px solid rgba(255,255,255,0.08)',
            borderRadius: '16px',
            padding: '32px',
          }}>
            {/* Card header */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '14px', paddingBottom: '24px', marginBottom: '26px', borderBottom: '1px solid rgba(255,255,255,0.07)' }}>
              <div style={{ width: '42px', height: '42px', borderRadius: '10px', background: 'linear-gradient(135deg, #4FB8D1, #1B7A93)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <svg width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
              </div>
              <div>
                <div style={{ fontFamily: 'DM Sans, sans-serif', fontWeight: 700, fontSize: '16px', color: '#fff' }}>Deal Machine</div>
                <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '13px', color: 'rgba(255,255,255,0.45)', marginTop: '2px' }}>Enter your deal details below</div>
              </div>
            </div>

            {/* Fields */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px', marginBottom: '14px' }}>
              <div>
                <label style={labelStyle}>Purchase price</label>
                <input style={inputStyle} type="number" placeholder="$0" value={form.purchasePrice} onChange={e => set('purchasePrice', e.target.value)} />
              </div>
              <div>
                <label style={labelStyle}>After repair value (ARV)</label>
                <input style={inputStyle} type="number" placeholder="$0" value={form.arv} onChange={e => set('arv', e.target.value)} />
              </div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px', marginBottom: '14px' }}>
              <div>
                <label style={labelStyle}>Rehab budget</label>
                <input style={inputStyle} type="number" placeholder="$0" value={form.rehab} onChange={e => set('rehab', e.target.value)} />
              </div>
              <div>
                <label style={labelStyle}>Other costs</label>
                <input style={inputStyle} type="number" placeholder="$0" value={form.otherCosts} onChange={e => set('otherCosts', e.target.value)} />
              </div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px', marginBottom: '14px' }}>
              <div>
                <label style={labelStyle}>Loan amount requested</label>
                <input style={inputStyle} type="number" placeholder="$0" value={form.loanAmount} onChange={e => set('loanAmount', e.target.value)} />
              </div>
              <div>
                <label style={labelStyle}>Deal type</label>
                <select style={{ ...inputStyle, cursor: 'pointer' }} value={form.dealType} onChange={e => set('dealType', e.target.value)}>
                  <option value="">Select type</option>
                  <option value="full">Full deal (1st position)</option>
                  <option value="bridge">Bridge / 2nd position</option>
                </select>
              </div>
            </div>
            <div style={{ marginBottom: '14px' }}>
              <label style={labelStyle}>Property address</label>
              <input style={inputStyle} type="text" placeholder="123 Main St, City, State" value={form.propertyAddress} onChange={e => set('propertyAddress', e.target.value)} />
            </div>

            {error && (
              <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '13px', color: '#ec6a6a', marginBottom: '12px' }}>{error}</div>
            )}

            <button
              onClick={analyze}
              style={{
                width: '100%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '8px',
                background: '#4FB8D1',
                color: '#0A1A33',
                fontFamily: 'DM Sans, sans-serif',
                fontSize: '15px',
                fontWeight: 700,
                border: 'none',
                borderRadius: '10px',
                padding: '0 22px',
                height: '48px',
                cursor: 'pointer',
                marginTop: '8px',
              }}
            >
              <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><path d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
              Run analysis
            </button>

            {/* Result */}
            {result && (
              <div id="dm-result" style={{
                marginTop: '22px',
                padding: '22px',
                borderRadius: '12px',
                background: result.isDeal ? 'rgba(70,197,133,0.08)' : 'rgba(236,106,106,0.08)',
                border: `1px solid ${result.isDeal ? 'rgba(70,197,133,0.25)' : 'rgba(236,106,106,0.25)'}`,
              }}>
                <div style={{ fontFamily: 'PT Serif, Georgia, serif', fontSize: '28px', fontWeight: 700, lineHeight: 1.1, marginBottom: '4px', color: result.isDeal ? '#46c585' : '#ec6a6a' }}>
                  {result.isDeal ? '✓ Deal' : '✗ No deal'}
                </div>
                <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '13.5px', color: 'rgba(255,255,255,0.6)', marginBottom: '16px', lineHeight: 1.55 }}>
                  {result.isDeal ? 'This deal meets our lending criteria. Ready to apply?' : result.reason}
                </div>

                {/* Metrics */}
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '10px', marginBottom: result.isDeal ? '16px' : '0' }}>
                  {[
                    { val: pct(result.ltv), label: 'LTV' },
                    { val: pct(result.ltc), label: 'LTC' },
                    { val: fmt(result.equity), label: 'Equity' },
                  ].map(m => (
                    <div key={m.label} style={{ background: 'rgba(255,255,255,0.05)', borderRadius: '8px', padding: '12px', textAlign: 'center' }}>
                      <div style={{ fontFamily: 'PT Serif, Georgia, serif', fontSize: '19px', fontWeight: 700, color: '#fff', lineHeight: 1.1 }}>{m.val}</div>
                      <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '10px', letterSpacing: '0.12em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.45)', marginTop: '3px' }}>{m.label}</div>
                    </div>
                  ))}
                </div>

                {result.isDeal && !submitted && (
                  <button
                    onClick={submitDeal}
                    disabled={submitting}
                    style={{
                      width: '100%',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '8px',
                      background: submitting ? 'rgba(240,106,42,0.5)' : '#F06A2A',
                      color: '#fff',
                      fontFamily: 'DM Sans, sans-serif',
                      fontSize: '15px',
                      fontWeight: 700,
                      border: 'none',
                      borderRadius: '10px',
                      padding: '0 22px',
                      height: '48px',
                      cursor: submitting ? 'not-allowed' : 'pointer',
                    }}
                  >
                    {submitting ? 'Submitting…' : 'Apply for funding →'}
                  </button>
                )}
                {result.isDeal && submitted && (
                  <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '14px', color: '#46c585', lineHeight: 1.6, padding: '12px 0' }}>
                    ✓ Deal submitted to our team! We'll be in touch shortly.<br/>
                    <a href="mailto:dellyinvests@dkgoldengate.com" style={{ color: 'rgba(255,255,255,0.5)', textDecoration: 'none', fontSize: '13px' }}>
                      Questions? dellyinvests@dkgoldengate.com
                    </a>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* APPLY SECTION */}
      <section style={{ background: '#060E1E', padding: '80px 0', borderTop: '1px solid rgba(255,255,255,0.04)' }} id="apply">
        <div style={{ maxWidth: '1180px', margin: '0 auto', padding: '0 32px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '64px', alignItems: 'start' }}>
          <div>
            <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '11px', fontWeight: 600, letterSpacing: '0.16em', textTransform: 'uppercase', color: '#7FCFE3', marginBottom: '12px' }}>
              Ready to move forward?
            </div>
            <h2 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: 'clamp(28px, 3vw, 42px)', lineHeight: 1.15, color: '#fff', marginBottom: '16px' }}>
              Submit your deal.
            </h2>
            <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '16px', lineHeight: 1.65, color: 'rgba(255,255,255,0.55)', marginBottom: '24px' }}>
              We lend to entities only — not individuals. Before submitting, have your LLC documents, three months of financial statements, and a verified experience profile ready.
            </p>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: '11px' }}>
              {[
                'Fix & flip or new construction of residential investment properties (single family to multifamily)',
                'No commercial properties — residential only',
                'Short-term bridge loan only — no conventional mortgages, no primary residences',
                'Preferred exit: sale or BRRRR (refinance into DSCR)',
                'Collateral preferred — developers who can bring assets to the table are given priority',
              ].map((item, i) => (
                <li key={i} style={{ display: 'flex', gap: '12px', alignItems: 'start', fontFamily: 'DM Sans, sans-serif', fontSize: '14px', lineHeight: 1.6, color: 'rgba(255,255,255,0.55)' }}>
                  <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#4FB8D1', flexShrink: 0, marginTop: '7px' }} />
                  {item}
                </li>
              ))}
            </ul>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '20px', paddingTop: '8px' }}>
            <a
              href="https://dkgv-onboarding.base44.app"
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '8px',
                background: '#F06A2A',
                color: '#fff',
                fontFamily: 'DM Sans, sans-serif',
                fontSize: '17px',
                fontWeight: 700,
                textDecoration: 'none',
                padding: '18px 44px',
                borderRadius: '10px',
              }}
            >
              Start your submission →
            </a>
            <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '14px', color: 'rgba(255,255,255,0.4)', lineHeight: 1.7 }}>
              Questions before submitting?<br />
              <a href="mailto:dellyinvests@dkgoldengate.com" style={{ color: '#7FCFE3', textDecoration: 'none' }}>
                dellyinvests@dkgoldengate.com
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
