import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import Layout from './components/Layout';

// Page imports
import Home from './pages/Home';
import Developers from './pages/Developers';
import Investors from './pages/Investors';
import HowItWorks from './pages/HowItWorks';
import Projects from './pages/Projects';
import DealMachine from './pages/DealMachine';
import ProjectsAdmin from './pages/admin/ProjectsAdmin';
import SeedProjects from './pages/SeedProjects';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center" style={{ background: '#0A1A33' }}>
        <div className="w-8 h-8 border-4 border-slate-700 border-t-slate-300 rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/developers" element={<Developers />} />
        <Route path="/investors" element={<Investors />} />
        <Route path="/how-it-works" element={<HowItWorks />} />
        <Route path="/projects" element={<Projects />} />
        <Route path="/deal-machine" element={<DealMachine />} />
        <Route path="/admin/projects" element={<ProjectsAdmin />} />
        <Route path="/seed-projects" element={<SeedProjects />} />
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  );
}

export default App;