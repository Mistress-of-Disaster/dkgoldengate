import { Link } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import ProjectCard from '../components/ProjectCard';
import ProjectModal from '../components/ProjectModal';

const S = {
  eyebrow: {
    fontFamily: 'DM Sans, sans-serif',
    fontSize: '13px',
    fontWeight: 600,
    letterSpacing: '0.14em',
    textTransform: 'uppercase',
    color: '#7FCFE3',
    marginBottom: '20px',
    display: 'block',
  },
  sectionLabel: {
    fontFamily: 'DM Sans, sans-serif',
    fontSize: '11px',
    fontWeight: 600,
    letterSpacing: '0.14em',
    textTransform: 'uppercase',
    color: '#97A2AF',
    marginBottom: '16px',
    display: 'block',
  },
};

export default function Home() {
  const [featuredProjects, setFeaturedProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState(null);

  useEffect(() => {
    base44.entities.Project.filter({ featured: true }, 'sort_order', 3).then(setFeaturedProjects);
  }, []);

  return (
    <div>
      {/* HERO */}
      <section style={{ background: '#0A1A33', minHeight: '100vh', display: 'flex', alignItems: 'center', paddingTop: '120px', paddingBottom: '80px' }}>
        <div style={{ maxWidth: '1280px', margin: '0 auto', padding: '0 32px', width: '100%' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '80px', alignItems: 'stretch' }} className="grid-cols-hero">
            {/* Left */}
            <div>
              <span style={S.eyebrow}>Boutique private real estate lender · Nationwide</span>
              <h1 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: 'clamp(36px, 5vw, 64px)', lineHeight: 1.1, color: '#FFFFFF', marginBottom: '8px' }}>
                Funding real estate deals.
              </h1>
              <h1 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: 'clamp(36px, 5vw, 64px)', lineHeight: 1.1, color: '#7FCFE3', marginBottom: '28px' }}>
                Building real partnerships.
              </h1>
              <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '17px', lineHeight: 1.65, color: 'rgba(255,255,255,0.65)', maxWidth: '480px', marginBottom: '40px' }}>
                DK Goldengate Ventures is a boutique private lender specializing in residential investment properties nationwide. We fund deals we believe in — and we stick around to make sure they succeed.
              </p>
              <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', marginBottom: '40px' }}>
                <Link to="/developers" style={{ background: '#F06A2A', color: '#FFFFFF', fontFamily: 'DM Sans, sans-serif', fontSize: '15px', fontWeight: 600, textDecoration: 'none', padding: '13px 28px', borderRadius: '4px', display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
                  Get funded →
                </Link>
                <Link to="/investors" style={{ background: 'transparent', color: '#FFFFFF', fontFamily: 'DM Sans, sans-serif', fontSize: '15px', fontWeight: 600, textDecoration: 'none', padding: '13px 28px', borderRadius: '4px', border: '1.5px solid rgba(255,255,255,0.35)', display: 'inline-block' }}>
                  Invest with us
                </Link>
              </div>
              {/* Contact row */}
              <div style={{ display: 'flex', gap: '20px', flexWrap: 'wrap', alignItems: 'center', borderTop: '1px solid rgba(255,255,255,0.08)', paddingTop: '28px' }}>
                <div>
                  <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '10px', fontWeight: 600, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.35)', marginBottom: '4px' }}>Call</div>
                  <a href="tel:+19256839794" style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '14px', color: 'rgba(255,255,255,0.7)', textDecoration: 'none' }}>(925) 683-9794</a>
                </div>
                <div style={{ width: '1px', height: '32px', background: 'rgba(255,255,255,0.1)', flexShrink: 0 }} />
                <div>
                  <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '10px', fontWeight: 600, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.35)', marginBottom: '4px' }}>Email</div>
                  <a href="mailto:dellyinvests@dkgoldengate.com" style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '14px', color: 'rgba(255,255,255,0.7)', textDecoration: 'none' }}>dellyinvests@dkgoldengate.com</a>
                </div>
                <div style={{ width: '1px', height: '32px', background: 'rgba(255,255,255,0.1)', flexShrink: 0 }} />
                <a href="https://calendar.google.com/calendar/appointments/schedules/AcZssZ2RR4bbnI4HKaSNmo-S8k16p1x_X5V0IQizHfQ9x1QM_gilna503I8efwnHPgTy2_8CwCjd9290?gv=true" target="_blank" rel="noopener noreferrer" style={{ background: '#7FCFE3', color: '#0A1A33', fontFamily: 'DM Sans, sans-serif', fontSize: '13px', fontWeight: 700, textDecoration: 'none', padding: '10px 18px', borderRadius: '4px', whiteSpace: 'nowrap' }}>
                  Book an appointment
                </a>
              </div>
            </div>

            {/* Right - Delly portrait card */}
            <div style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'stretch' }}>
              <div style={{ position: 'relative', border: '1px solid rgba(127,207,227,0.12)', borderRadius: '8px', overflow: 'hidden', width: '100%', minHeight: '480px' }}>
                <img
                  src="https://base44.app/api/apps/69b82174571b99319d3f3dbc/files/mp/public/69b82174571b99319d3f3dbc/1b9817bd7_Delly_Home.png"
                  alt="Delband Delly Kerachi, Founder"
                  style={{ width: '100%', height: '100%', display: 'block', objectFit: 'cover', objectPosition: 'top center', position: 'absolute', inset: 0 }}
                />
                {/* Bottom overlay — name + quote */}
                <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, background: 'linear-gradient(to top, rgba(10,26,51,0.97) 0%, rgba(10,26,51,0.6) 60%, transparent 100%)', padding: '48px 24px 28px' }}>
                  <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '10px', fontWeight: 700, letterSpacing: '0.14em', textTransform: 'uppercase', color: '#7FCFE3', marginBottom: '4px' }}>Founder & Owner</div>
                  <div style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: '18px', color: '#FFFFFF', lineHeight: 1.2, marginBottom: '16px' }}>Delband "Delly" Kerachi</div>
                  <div style={{ borderTop: '1px solid rgba(255,255,255,0.12)', paddingTop: '16px' }}>
                    <p style={{ fontFamily: 'PT Serif, Georgia, serif', fontSize: '14px', lineHeight: 1.65, color: 'rgba(255,255,255,0.75)', fontStyle: 'italic', margin: 0 }}>
                      "My goal is to build lasting partnerships, not one-time transactions."
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ABOUT */}
      <section style={{ background: '#FFFFFF', padding: '72px 0' }}>
        <div style={{ maxWidth: '1280px', margin: '0 auto', padding: '0 32px' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '80px', alignItems: 'start', marginBottom: '80px' }} className="grid-cols-hero">
            <div>
              <span style={S.sectionLabel}>About Delly</span>
              <h2 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: 'clamp(28px, 3.5vw, 48px)', lineHeight: 1.15, color: '#0A1A33' }}>
                A name behind every deal.
              </h2>
            </div>
            <div>
              <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '17px', lineHeight: 1.7, color: '#4B5563', marginBottom: '20px' }}>
                DK GoldenGate was founded with a clear purpose: to give real estate developers access to the capital they need — and too often can't find. Delband Kerachi saw the gap and stepped in to fill it, not primarily to maximize returns, but to genuinely enable developers to get more deals done.
              </p>
              <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '17px', lineHeight: 1.7, color: '#4B5563', marginBottom: '20px' }}>
                <strong style={{ color: '#0A1A33' }}>DK stands for Delband Kerachi.</strong> Based in San Francisco and backed by a Silicon Valley investor network, Delly brings 13 years of project management experience spanning real estate and restaurant franchise operations — which means she understands the business behind the deal, not just the numbers on the page.
              </p>
              <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '17px', lineHeight: 1.7, color: '#4B5563' }}>
                Her name and her reputation are behind every project she funds. She partners with developers who understand that motivation alone is not enough — organization, disciplined budgeting, foresight, and the ability to pivot when challenges arise are what separate successful projects from costly ones.
              </p>
            </div>
          </div>

          {/* Stats row */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '1px', background: '#DCE2EA', border: '1px solid #DCE2EA', borderRadius: '6px', overflow: 'hidden' }} className="grid-cols-3-1">
            {[
              { label: 'Track record', value: 'Successfully closing deals since 2024', sub: 'SFH and multifamily deals across the U.S.' },
              { label: 'What we fund', value: 'Bridge (gap) & whole-deal funding', sub: 'Residential fix & flip and new construction' },
              { label: 'Funding capacity', value: 'Gap $30K–$500K · Whole deal $100K to several million', sub: 'Sized to the deal — not forced to fit a preset menu' },
            ].map((s) => (
              <div key={s.label} style={{ background: '#F6F8FA', padding: '32px 28px' }}>
                <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '10px', fontWeight: 700, letterSpacing: '0.14em', textTransform: 'uppercase', color: '#97A2AF', marginBottom: '10px' }}>{s.label}</div>
                <div style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: '20px', color: '#0A1A33', lineHeight: 1.3, marginBottom: '8px' }}>{s.value}</div>
                <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '13px', color: '#97A2AF', lineHeight: 1.5 }}>{s.sub}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURED PROJECTS */}
      <section style={{ background: '#FFFFFF', padding: '0 0 72px' }}>
        <div style={{ maxWidth: '1280px', margin: '0 auto', padding: '0 32px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: '16px', flexWrap: 'wrap', gap: '16px' }}>
            <div>
              <span style={S.sectionLabel}>Featured projects</span>
              <h2 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: 'clamp(28px, 3.5vw, 48px)', color: '#0A1A33', lineHeight: 1.15 }}>
                Hall of Fame - Our<br />Deal Highlights.
              </h2>
              <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '16px', lineHeight: 1.6, color: '#4B5563', maxWidth: '500px', marginTop: '16px' }}>
                From the East Coast to the West Coast — we've partnered with developers across the country on residential projects that deliver results and are prime real estate.
              </p>
            </div>
            <Link to="/projects" style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '14px', fontWeight: 500, color: '#1E4076', textDecoration: 'none', border: '1px solid #DCE2EA', padding: '10px 20px', borderRadius: '4px', whiteSpace: 'nowrap' }}>
              View all featured projects →
            </Link>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '28px', marginTop: '48px' }} className="grid-cols-3-1">
            {featuredProjects.map(p => (
              <ProjectCard key={p.id} project={p} onClick={() => setSelectedProject(p)} />
            ))}
          </div>
        </div>
      </section>

      {selectedProject && (
        <ProjectModal project={selectedProject} onClose={() => setSelectedProject(null)} />
      )}

      {/* DUAL CTA */}
      <section style={{ background: '#F6F8FA', padding: '56px 0', borderTop: '1px solid #DCE2EA' }}>
        <div style={{ maxWidth: '1280px', margin: '0 auto', padding: '0 32px' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }} className="grid-cols-hero">
            {/* Developers */}
            <div style={{ background: '#0F2545', borderRadius: '8px', padding: '48px 40px' }}>
              <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '11px', fontWeight: 700, letterSpacing: '0.14em', textTransform: 'uppercase', color: '#7FCFE3', marginBottom: '16px' }}>For developers</div>
              <h3 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: 'clamp(22px, 2.5vw, 32px)', color: '#FFFFFF', lineHeight: 1.2, marginBottom: '16px' }}>Real estate developer?</h3>
              <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '15px', lineHeight: 1.65, color: 'rgba(255,255,255,0.6)', marginBottom: '32px' }}>
                Get deal funding tailored to your project — fast, flexible, and from a lender who's genuinely invested in your success.
              </p>
              <Link to="/developers" style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '14px', fontWeight: 600, color: '#7FCFE3', textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
                Get funded →
              </Link>
            </div>
            {/* Investors */}
            <div style={{ background: '#F0F4F8', border: '1px solid #DCE2EA', borderRadius: '8px', padding: '48px 40px' }}>
              <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '11px', fontWeight: 700, letterSpacing: '0.14em', textTransform: 'uppercase', color: '#2A9BB8', marginBottom: '16px' }}>For investors</div>
              <h3 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: 'clamp(22px, 2.5vw, 32px)', color: '#0A1A33', lineHeight: 1.2, marginBottom: '16px' }}>Looking to invest?</h3>
              <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '15px', lineHeight: 1.65, color: '#4B5563', marginBottom: '32px' }}>
                Earn strong returns by funding vetted residential real estate deals with full transparency and real asset-backed security.
              </p>
              <Link to="/investors" style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '14px', fontWeight: 600, color: '#1E4076', textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
                Start investing →
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}