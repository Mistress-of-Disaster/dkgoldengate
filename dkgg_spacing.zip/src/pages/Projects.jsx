import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import ProjectModal from '../components/ProjectModal';

export default function Projects() {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedProject, setSelectedProject] = useState(null);

  useEffect(() => {
    base44.entities.Project.list('sort_order', 200).then(data => {
      setProjects(data.filter(p => p.status !== 'Archived'));
      setLoading(false);
    });
  }, []);

  return (
    <div>
      {/* HERO */}
      <section style={{ background: '#0A1A33', paddingTop: '160px', paddingBottom: '80px' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '0 32px' }}>
          <span style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '11px', fontWeight: 600, letterSpacing: '0.14em', textTransform: 'uppercase', color: '#F06A2A', marginBottom: '20px', display: 'block' }}>
            Our portfolio
          </span>
          <h1 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: 'clamp(36px, 5vw, 60px)', lineHeight: 1.1, color: '#FFFFFF', marginBottom: '24px' }}>
            Hall of Fame -<br />Deal highlights.
          </h1>
          <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '17px', lineHeight: 1.65, color: 'rgba(255,255,255,0.6)', maxWidth: '520px' }}>
            A selection of residential real estate projects we've proudly funded across the United States. From the East Coast to the West Coast — each one representing a developer we believed in and a deal we successfully closed.
          </p>
        </div>
      </section>

      {/* GRID */}
      <section style={{ background: '#FFFFFF', padding: '64px 0', minHeight: '60vh' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '0 32px' }}>
          {loading ? (
            <div style={{ textAlign: 'center', padding: '56px 0', fontFamily: 'DM Sans, sans-serif', fontSize: '15px', color: '#97A2AF' }}>
              Loading projects…
            </div>
          ) : (
            <>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '32px 28px' }} className="grid-cols-3-1">
                {projects.map((p) => (
                  <ProjectCard key={p.id} project={p} onClick={() => setSelectedProject(p)} />
                ))}
              </div>

              {projects.length === 0 && (
                <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '15px', color: '#97A2AF', textAlign: 'center', padding: '56px 0' }}>
                  No projects to display yet.
                </p>
              )}
            </>
          )}
        </div>
      </section>

      {selectedProject && (
        <ProjectModal project={selectedProject} onClose={() => setSelectedProject(null)} />
      )}

      {/* CTA */}
      <section style={{ background: '#F6F8FA', padding: '56px 0', borderTop: '1px solid #DCE2EA' }}>
        <div style={{ maxWidth: '900px', margin: '0 auto', padding: '0 32px' }}>
          <div style={{ background: '#0F2545', borderRadius: '8px', padding: '48px 52px' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '40px', alignItems: 'start' }} className="grid-cols-hero">
              <div>
                <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '11px', fontWeight: 600, letterSpacing: '0.14em', textTransform: 'uppercase', color: '#7FCFE3', marginBottom: '16px' }}>
                  Your project · Next
                </div>
                <h3 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: 'clamp(22px, 2.5vw, 30px)', color: '#FFFFFF', lineHeight: 1.2, marginBottom: '12px' }}>
                  Have a deal worth funding?
                </h3>
                <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '14px', lineHeight: 1.65, color: 'rgba(255,255,255,0.5)', margin: 0 }}>
                  Let's talk. Initial conversations are always no-obligation, free of charge, and confidential.
                </p>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                <a href="mailto:dellyinvests@dkgoldengate.com" style={{ background: '#7FCFE3', color: '#0A1A33', fontFamily: 'DM Sans, sans-serif', fontSize: '14px', fontWeight: 700, textDecoration: 'none', padding: '13px 20px', borderRadius: '4px', textAlign: 'center' }}>
                  dellyinvests@dkgoldengate.com
                </a>
                <a href="https://calendar.google.com/calendar/appointments/schedules/AcZssZ2RR4bbnI4HKaSNmo-S8k16p1x_X5V0IQizHfQ9x1QM_gilna503I8efwnHPgTy2_8CwCjd9290?gv=true" target="_blank" rel="noopener noreferrer" style={{ background: 'transparent', color: '#7FCFE3', fontFamily: 'DM Sans, sans-serif', fontSize: '14px', fontWeight: 500, textDecoration: 'none', padding: '13px 20px', borderRadius: '4px', border: '1px solid rgba(127,207,227,0.3)', textAlign: 'center' }}>
                  Book an appointment
                </a>
                <a href="tel:+19256839794" style={{ background: 'transparent', color: 'rgba(255,255,255,0.55)', fontFamily: 'DM Sans, sans-serif', fontSize: '14px', fontWeight: 500, textDecoration: 'none', padding: '13px 20px', borderRadius: '4px', border: '1px solid rgba(255,255,255,0.15)', textAlign: 'center' }}>
                  (925) 683-9794
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function ProjectCard({ project, onClick }) {
  const [hovered, setHovered] = useState(false);
  const hasImage = !!project.cover_image_url;

  return (
    <article
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{ cursor: 'pointer' }}
    >
      {/* Image */}
      <div style={{ position: 'relative', borderRadius: '6px', overflow: 'hidden', marginBottom: '16px', background: '#0F2545' }}>
        {hasImage ? (
          <img
            src={project.cover_image_url}
            alt={project.name}
            style={{ width: '100%', height: '200px', objectFit: 'cover', display: 'block', transition: 'transform 0.3s ease', transform: hovered ? 'scale(1.03)' : 'scale(1)' }}
          />
        ) : (
          <div style={{ height: '200px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '8px', color: '#97A2AF' }}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>
            <span style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '12px' }}>Drop project photo<br />or browse files</span>
          </div>
        )}
        {/* Region badge */}
        {project.region && (
          <div style={{ position: 'absolute', top: '10px', left: '10px', background: 'rgba(10,26,51,0.85)', color: '#FFFFFF', fontFamily: 'DM Sans, sans-serif', fontSize: '10px', fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', padding: '4px 10px', borderRadius: '3px' }}>
            {project.region}
          </div>
        )}
      </div>

      <h3 style={{ fontFamily: 'PT Serif, Georgia, serif', fontWeight: 700, fontSize: '18px', color: '#0A1A33', lineHeight: 1.25, marginBottom: '6px' }}>
        {project.name}
      </h3>
      <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '12px', fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: '#97A2AF' }}>
        {[project.region, project.strategy, project.funding_type].filter(Boolean).join(' · ')}
      </div>
    </article>
  );
}